<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('categoryCreateView')); ?>">Create Category</a>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">Name</th>
            <th scope="col">Category</th>
            <th scope="col">In Stock</th>
            <th scope="col">Qunatity<th>
            <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($product->name); ?></td>
            <td><?php echo e($product->category); ?></td>
            <td><?php echo e($product->in_stock); ?></td>
            <td><?php echo e($product->quantity); ?></td>
            <td><button onclick="confirm('Are you relaly wwant to delete this item')">Delete</button></td>
        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Новая папка (2)\assignment\resources\views/product/index.blade.php ENDPATH**/ ?>